
public class Ingresso {

	protected double valor;
	
	public void retornaValor() {
		System.out.println("Valor: " + valor);
	}

	public Ingresso(double valor) {
		this.valor = valor;
	}
	
	
	
		
}
