
public class IngressoNormal extends Ingresso {
	
	
	
	public IngressoNormal(double valor) {
		super(valor);
	}

	@Override
	public String toString() {
		return "Valor do Ingresso Normal: R$" + super.valor;
	}
	
}
