import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Digite o valor do Ingresso: ");
		double valorDoIngresso = scan.nextDouble();
		
		IngressoNormal normal = new IngressoNormal (valorDoIngresso);
		IngressoVip vip = new IngressoVip(valorDoIngresso);
		
	
		System.out.println(normal);
		System.out.println(vip);
	}

}
