
public enum Localizacao {

	
	CAMAROTE_SUPERIOR(0.5), CAMAROTE_INFERIOR(0.7);
	
	protected double acrescimo;
	
	Localizacao (double acrescimo) {
		this.acrescimo = acrescimo;
	}
	
}
