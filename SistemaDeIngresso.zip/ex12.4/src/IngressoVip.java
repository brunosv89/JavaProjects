
public class IngressoVip extends Ingresso {

	public IngressoVip(double valor) {
		super(valor);
	}


	Localizacao localizacao;
	
	protected double valorSup = ((super.valor * Localizacao.CAMAROTE_SUPERIOR.acrescimo) + super.valor);
	protected double valorInf = ((super.valor * Localizacao.CAMAROTE_INFERIOR.acrescimo) + super.valor);
	
	
	
	@Override
	public String toString() {
		return "Valor do Ingresso VIP:\n----- Camarote Superior: R$" + valorSup + "\n----- Camarote Inferior: R$" + valorInf; 
	}
	
}
