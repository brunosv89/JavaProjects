package br.com.unisc.ex31;

import java.util.Scanner;

public class PedidoDeFabricacao {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Digite a quantidade de carros que deseja criar: ");
		int n = scan.nextInt();
		
		Carro vetor[] = new Carro[n];
		
		System.out.println("Agora vamos montar os carros.");
		
		for (int i=0; i < vetor.length; i++) {
			System.out.println("--------------------");
			System.out.println("Carro n� " + (i+1) + ":");
			System.out.println("Digite o modelo: ");
			String modelo = scan.next();
			System.out.println("Digite o tipo: ");
			String tipo = scan.next();
			Carro carro = new Carro (modelo, tipo);  //criando objeto carro com os atributos informados
			vetor[i] = carro;
			System.out.println("Agora vamos pintar o carro. Qual cor voc� deseja? ");
			String cor = scan.next();
			carro.pintar(cor);  //chamando m�todo pintar
			
		}
		System.out.println("<><><><><><><><><><><><><>");
		System.out.println("Tabela de carros criados: ");
		for (int i=0; i < vetor.length; i++) {
			System.out.println(vetor[i]);
		};
		
		
		
	}

}
