package br.com.unisc.ex31;

public class Carro {

	private String cor; 
	private int ano;
	private String modelo; //"nome"
	private String tipo;   //sedan, hatch, pick-up, etc..
	
	public Carro (String modelo, String tipo) {
		System.out.println("Carro fabricado.");
		this.modelo = modelo;
		this.tipo = tipo;
		this.ano = 2021;
	}
	
	public void pintar (String cor) {
		this.cor = cor;
	}
	
	@Override
	public String toString() {
		return "[Carro: " + this.modelo + ", tipo: " + this.tipo + ", cor: " + 
				this.cor + ", ano: " + this.ano + ".]";
	}
	
}
