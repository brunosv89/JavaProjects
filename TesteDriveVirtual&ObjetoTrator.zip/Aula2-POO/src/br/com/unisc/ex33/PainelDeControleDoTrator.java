package br.com.unisc.ex33;

import java.util.Scanner;

public class PainelDeControleDoTrator {

	public static void main(String[] args) throws Exception {
		System.out.println("Bem-vindo ao test-drive digital.");
		System.out.println("Vamos escolher um trator");
		System.out.println("Qual a marca voc� deseja testar: ");
		Scanner scan = new Scanner(System.in);
		String marca = scan.nextLine();
		System.out.println("Temos todas as cores. Qual voc� deseja: ");
		String cor = scan.nextLine();
		
		Trator trator = new Trator(marca, cor);
		System.out.println("Trator escolhido, vamos para o test-drive.");
		
		while (true) {
		
			System.out.println("Digite a op��o que deseja: ");
			System.out.println("[1] - Mostrar caracter�sticas");
			System.out.println("[2] - Ligar");
			System.out.println("[3] - Andar");
			System.out.println("[4] - Reduzir Marcha");
			System.out.println("[5] - Subir Marcha");
			System.out.println("[6] - Desligar");
			System.out.println("[0] - Sair do test-drive digital");
			System.out.println("Op��o: ");
			int op = scan.nextInt();
			System.out.println("-----------------------");
			switch (op) {
			case 1:
				trator.mostrarCarac();
				System.out.println("-----------------------");
				Thread.sleep(5000);
				break;
			case 2:
				trator.ligar();
				System.out.println("-----------------------");
				Thread.sleep(2000);
				break;
			case 3:
				trator.andar();
				System.out.println("-----------------------");
				Thread.sleep(2000);
				break;
			case 4:
				trator.reduzirMarcha();
				System.out.println("-----------------------");
				Thread.sleep(2000);
				break;
			case 5:
				trator.subirMarcha();
				System.out.println("-----------------------");
				Thread.sleep(2000);
				break;
			case 6:
				trator.desligar();
				System.out.println("-----------------------");
				Thread.sleep(2000);
				break;
			case 0:
				System.out.println("Saindo do test-drive digital.");
				System.exit(0);
			}
				
		}
		
	}

}
