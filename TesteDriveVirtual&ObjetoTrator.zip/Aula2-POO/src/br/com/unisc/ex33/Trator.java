package br.com.unisc.ex33;

public class Trator {

	//Attributes
	public String cor;
	private String marca;
	private int marcha;
	//protected boolean revisado;
	protected boolean ligado;
	
	//Constructor
	public Trator (String marca, String cor) {
		System.out.println("Trator digital criado.");
		this.marca = marca;
		this.cor = cor;
		this.ligado = false;
		this.marcha = 0;
	}

	//Getters & Setters
	/*
	 * N�o foi necess�ria a utiliza��o
	 */
	
	//Methods
	
	public void mostrarCarac () {
		System.out.println("[[ Computador de bordo ]]");
		System.out.println("Marca: " + this.marca + ", Cor:" + this.cor);
		if (this.ligado == true) {
			System.out.println("O trator est�: Ligado");
			System.out.println("Marcha atual: " + this.marcha);
		} else {
			System.out.println("O trator est� desligado.");
		}
		
	}
	
	public void ligar () {
		if (this.ligado) {
			System.out.println("J� est� ligado.");
		} else {
			this.ligado = true;
			System.out.println("Ligando..");
		}
	}

	public void andar() {
		if (this.ligado && marcha != 0) {
			System.out.println("VROMMMMM tec tec tec tec");
		} else {
			System.out.println("Voc� precisa ligar o trator antes e engatar marcha.");
		}
	}

	public void reduzirMarcha() {
		if (marcha != 0) {
			marcha--;
			System.out.println("Reduzindo marcha. Voc� est� na " + this.marcha + " marcha.");
		} else {
			System.out.println("Voc� j� est� em ponto morto.");
		}
	}
	public void subirMarcha() {
		if(marcha < 3) {
			marcha++;
			System.out.println("Subindo marcha. Voc� est� na " + this.marcha + " marcha.");
		} else {
			System.out.println("Acalma o cora��o, voc� j� est� na �ltima marcha!");
		}
	}
		
	public void desligar() {
		this.ligado = false;
		System.out.println("Trator desligado.");
			
	}
	
	
}
