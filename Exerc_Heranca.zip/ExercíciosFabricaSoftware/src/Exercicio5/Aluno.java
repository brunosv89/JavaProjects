package Exercicio5;

import java.util.Scanner;

/*
typedef struct Aluno{
int matricula;
char nome[50];
float n_p1;
float n_p2;
float n_trab;
float n_ex;
float n_media;
}Aluno;
float calcula_media(float n1, float n2, float n3, float n4){
	return (n1+n2+n3+n4)/4.0;
}
void main(){
	Aluno a;
	scanf(�%f %f %f %f�, &a.n_p1, &a.n_p2, &a.n_trab, &a.n_ex);
	a.n_media = calcula_media(a.n_p1, a.n_p2, a.n_trab, a.n_ex);
}
 * */


public class Aluno {

	private String nome;
	private int matricula;
	private float n_media;
	
	public Aluno() {
		this.nome = nome;
		this.matricula = matricula;
	}

	public float calcula_media(float n1, float n2, float n3, float n4) {
		return this.n_media = (n1+n2+n3+n4) / 4.0f;
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		Aluno a = new Aluno();
		
		System.out.println("Digite a nota 1:");
		float n1 = scan.nextFloat();
		System.out.println("Digite a nota 2:");
		float n2 = scan.nextFloat();
		System.out.println("Digite a nota 3:");
		float n3 = scan.nextFloat();
		System.out.println("Digite a nota 4:");
		float n4 = scan.nextFloat();
		
		a.calcula_media(n1, n2, n3, n4);
		System.out.println("Media do aluno:" + a.n_media);
	}
	
	
}







