package ControleRemoto;

public class ControleRemoto {

	public final int MAXVOL = 100;
	
	private String modelo;
	private float tamanho;
	private int volume;
	
	public boolean ligado;
	
	public ControleRemoto(String modelo, float tamanho) {
		this.modelo = modelo;
		this.tamanho = tamanho;
	}
	
	public void aumentarVolume() {
		if (volume!=MAXVOL)
			volume++;
	}
	
	public void diminuirVolume() {
		if (volume!=0)
			volume--;
	}
	
	public void ligar() {
		ligado = true;
	}
	
	public void desligar() {
		ligado = false;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public float getTamanho() {
		return tamanho;
	}

	public void setTamanho(float tamanho) {
		this.tamanho = tamanho;
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}
}
