package Trabalho;

public class Trabalho {
	
	
	public boolean empregado;
	
	private float salario;
	private int dificuldade = 10;
	private int jornada;
	public String cargo;
	
	
	public Trabalho(String cargo) {
		this.cargo = cargo;
	}

	public void promocao() {
		dificuldade +=10;
		salario += 1000;
	}
	
	public void demissao() {
		empregado = false;
		salario = 0;
		dificuldade = 0;
		jornada = 0;
		cargo = null;
	}

	public float getSalario() {
		return salario;
	}

	public void setSalario(float salario) {
		this.salario = salario;
	}

	public int getDificuldade() {
		return dificuldade;
	}

	public void setDificuldade(int dificuldade) {
		this.dificuldade = dificuldade;
	}

	public int getJornada() {
		return jornada;
	}

	public void setJornada(int jornada) {
		this.jornada = jornada;
	}
	
	
	
}
