package Cachorro;

public class Cachorro {

	public int idade;
	public float peso;
	public boolean limpo;
	
	
	public Cachorro(int idade, float peso) {
		this.idade = idade;
		this.peso = peso;
	}
	
	public void alimentar() {
		peso++;
	}
	
	public void passear() {
		peso--;
		limpo = false;
	}
	

	public void banho() {
		limpo = true;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}

	public boolean isLimpo() {
		return limpo;
	}

	public void setLimpo(boolean limpo) {
		this.limpo = limpo;
	}

}
