package ex2;

public class Main {

	public static void main(String[] args) {

		//Criando funcion�rios
		//40% ensino b�sico
		Funcionario f1 = new Vendedor("Aderbal", 8924);
		Funcionario f2 = new Vendedor("Rosa", 3289);
		Funcionario f3 = new Vendedor("Amarildes", 8422);
		Funcionario f4 = new Vendedor("Aristeu", 4521);
		//40% ensino m�dio
		Funcionario f5 = new Supervisor("Jiraya", 3233, "Escola A");
		Funcionario f6 = new Vendedor("Neymar", 1131, "Escola B");
		Funcionario f7 = new Gerente("Robinho", 0110, "Escola B");
		Funcionario f8 = new Supervisor("Densel", 9212, "EJA");
		//20% ensino superior
		Funcionario f9 = new Gerente("Suzana", 7621, "Escola B", "UNISC");
		Funcionario f0 = new Supervisor("Jonas", 1450, "Escola A", "UNISC");
		
		//adicionando funcion�rios no array	
		//Funcionario[] empresa = {f4,f6,f0,f1,f3,f2,f7,f9,f5,f8};
		Funcionario[] empresa = {f1,f2,f3,f4,f5,f6,f7,f8,f9, f0};
		
		
		
		for (Funcionario funcionario : empresa) {
			System.out.println(funcionario);
		}
		custoEmpresa(empresa);
		
	}
	
	public static double custoEmpresa(Funcionario[] empresa) {
		double total = 0;
		
		
		double ensinoBasico = 0, ensinoMedio = 0, graduacao = 0;
		
		for (Funcionario funcionario : empresa) {
			if (funcionario.getEscolaridade() == 1){
				ensinoBasico += funcionario.getSalario();
			}
			else if (funcionario.getEscolaridade() == 2){
				ensinoMedio += funcionario.getSalario();
			}
			else {
				graduacao += funcionario.getSalario();
			}
			
		}
		
		
		System.out.println("\n\nO custo total da empresa �: R$" + (ensinoBasico + ensinoMedio + graduacao));
		
		System.out.println("\n-Ensino B�sico: " + ensinoBasico);
		System.out.println("-Ensino M�dio: " + ensinoMedio);
		System.out.println("-Ensino Superior: " + graduacao);
		
		return total;
	}
	

}
