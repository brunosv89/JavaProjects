package ex2;

public class Funcionario {

	private String nome;
	private int codigo;
	private String escola;
	private String faculdade;
	private final double rendaBasica = 1000.0;
	protected int escolaridade;
	
	protected double salario = rendaBasica;
	
	


	public Funcionario (String nome, int codigo) {
		this.nome = nome;
		this.codigo = codigo;
		this.escola = "N�o concluiu";
		this.faculdade = "N�o concluiu";
		this.escolaridade = 1;
	}
	
	public Funcionario (String nome, int codigo, String escola) {
		this.nome = nome;
		this.codigo = codigo;
		this.escola = escola;
		this.faculdade = "N�o concluiu";
		this.escolaridade = 2;
	}
	
	public Funcionario (String nome, int codigo, String escola, String faculdade) {
		this.nome = nome;
		this.codigo = codigo;
		this.escola = escola;
		this.faculdade = faculdade;
		this.escolaridade = 3;
	}
	
	
		
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	public int getEscolaridade() {
		return escolaridade;
	}

	public void setEscolaridade(int escolaridade) {
		this.escolaridade = escolaridade;
	}
	
	public double getBonificacao (int escolaridade) {
		double renda1 = this.rendaBasica + (this.rendaBasica * 0.1);
		double renda2 = renda1 + (renda1 * 0.5);
		double renda3 = renda2 + (renda2 * 2);
		if (escolaridade == 1)
			return renda1;
		else if (escolaridade == 2)
			return renda2;
		else
			return renda3;
		}
	
	
	
}
