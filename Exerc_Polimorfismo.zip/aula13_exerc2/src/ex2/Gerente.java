package ex2;

public class Gerente extends Funcionario {
	
	private double comissao = 1500;

	public Gerente(String nome, int codigo) {
		super(nome, codigo);
		this.escolaridade = 1;
		this.salario = super.getBonificacao(this.escolaridade) + this.comissao;
	}

	public Gerente (String nome, int codigo, String escola) {
		super(nome, codigo, escola);
		this.escolaridade = 2;
		this.salario = super.getBonificacao(this.escolaridade) + this.comissao;
	}
	
	public Gerente (String nome, int codigo, String escola, String faculdade) {
		super(nome, codigo, escola, faculdade);
		this.escolaridade = 3;
		this.salario = super.getBonificacao(this.escolaridade) + this.comissao;
	}
	
	
	
	@Override
	public String toString() {
		return "Nome: " + super.getNome() + ", Comiss�o: " + this.comissao + ", Salario: " + this.getSalario() + "."; 
	}
	
	
	
}
