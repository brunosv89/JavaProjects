import java.io.Console;
import java.io.IOException;
import java.util.Scanner;

import Animais.Mamifero;
import Animais.Peixe;
import Animais.Reptil;

public class Main {


	public static void main(String[] args) {
		Main programa = new Main();
		Scanner scan = new Scanner(System.in);

		int opc = -1;
		while(opc != 0)
		{
			System.out.println("=========================");
			System.out.println("Op��o 1 para chamar veterin�rio!");
			System.out.println("Op��o 2 para andar pelo zool�gico!");
			System.out.println("Op��o 0 para sair!");
			System.out.println("=========================");	

			System.out.println("Digite a op��o desejada");
			opc = scan.nextInt();
			
			switch(opc) {
			
			case 1:
				programa.chamarVet();
				break;
				
			case 2:
				programa.zoo();;
				break;
				
			case 0:
				System.out.println("SAINDO!");
				break;
			
			default:
				break;
			}


		}
		
		
		


	}
	
	
	private void chamarVet() {
		Veterinario vet = new Veterinario();
		vet.examinar(new Mamifero());
		vet.examinar(new Peixe());
		vet.examinar(new Reptil());

	}
	
	private void zoo() {
		Zoologico zoo = new Zoologico();
		zoo.percorrerJaulas();
	}
	
	

}
