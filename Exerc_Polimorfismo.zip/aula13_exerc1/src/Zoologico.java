import java.util.ArrayList;

import Animais.Animal;
import Animais.Ave;
import Animais.Mamifero;
import Animais.Peixe;
import Animais.Reptil;

public class Zoologico {

	ArrayList<Animal> jaulas = new ArrayList<Animal>();
	
	
	public Zoologico() {
		alocandoAnimais();
	}
	
	
	public void percorrerJaulas() {
		for (int i=0; i< jaulas.size(); i++) {
			jaulas.get(i).emitirSom();
			jaulas.get(i).locomover();
		}
	}
	
	
	
	private void alocandoAnimais() {	
		Reptil jacare = new Reptil();
		Reptil tartaruga = new Reptil();
		Reptil lagarto= new Reptil();
		Ave pelicano = new Ave();
		Ave pinguim = new Ave();
		Ave pavao = new Ave();
		Mamifero leao = new Mamifero();	
		Mamifero zebra = new Mamifero();	
		Mamifero elefante = new Mamifero();	
		Peixe peixe_palhaco = new Peixe();
		
		jaulas.add(jacare);
		jaulas.add(tartaruga);
		jaulas.add(lagarto);
		jaulas.add(pelicano);
		jaulas.add(pinguim);
		jaulas.add(pavao);
		jaulas.add(leao);
		jaulas.add(zebra);
		jaulas.add(elefante);
		jaulas.add(peixe_palhaco);

	}
	
	
}
