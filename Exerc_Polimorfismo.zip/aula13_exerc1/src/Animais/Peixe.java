package Animais;

public class Peixe extends Animal{

	private String corEscama;
	
	
	public Peixe() {
		// TODO Auto-generated constructor stub
	}

	public void SoltarBolha() {
		System.out.println("Soltando bolha");
	}
	

	public String getCorEscama() {
		return corEscama;
	}
	
	@Override
	public void emitirSom() {
		System.out.println("Sons de peixe!");
		SoltarBolha();
	}

	public void setCorEscama(String corEscama) {
		this.corEscama = corEscama;
	}

}
