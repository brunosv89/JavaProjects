package Animais;

public class Ave extends Animal {
	private String corPena;
	
	public Ave() {
		super();
	}

	public void fazerNinho() {
		System.out.println("Ninho sendo constru�do!");
	}
	
	public void locomover(int velocidade) {
		System.out.println("Voando a " + velocidade + "km/h!");
	}
	
	@Override
	public void emitirSom() {
		System.out.println("Sons de aves!");
	}
	
	public String getCorPena() {
		return corPena;
	}

	public void setCorPena(String corPena) {
		this.corPena = corPena;
	}

	
	
}
