package Animais;

public class Mamifero extends Animal{

	private String corPelo;

	
	public Mamifero() {
		super();
	}
	
	@Override
	public void locomover() {
		System.out.println("Correndo!");
	}

	@Override
	public void emitirSom() {
		System.out.println("Sons de mam�feros!");
	}
	
	public String getCorPelo() {
		return corPelo;
	}

	public void setCorPelo(String corPelo) {
		this.corPelo = corPelo;
	}

}
