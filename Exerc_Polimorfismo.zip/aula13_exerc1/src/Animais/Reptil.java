package Animais;

public class Reptil extends Animal{
	
	private String corEscamaString;
	
	public Reptil() {
		super();
	}

	public String getCorEscamaString() {
		return corEscamaString;
	}

	public void setCorEscamaString(String corEscamaString) {
		this.corEscamaString = corEscamaString;
	}
	
	@Override
	public void locomover() {
		System.out.println("Rastejando!");
	}

	

}
