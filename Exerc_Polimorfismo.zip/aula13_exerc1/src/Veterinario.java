import Animais.Animal;

public class Veterinario {

	public Veterinario() {
	}

	public void examinar(Animal animal) {
		animal.emitirSom();
	}
}
