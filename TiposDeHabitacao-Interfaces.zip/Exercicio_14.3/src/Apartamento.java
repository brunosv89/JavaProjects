
public class Apartamento extends Habitacao{

	private float areaSacada;	
	private boolean elevador;
	private boolean churrasqueira;
	
	public Apartamento() {
		super();
	}

	public Apartamento(float areaConstruida, int numQuartos, int numBanheiros, boolean garagem, TipoPiso tipoPiso) {
		super(areaConstruida, numQuartos, numBanheiros, garagem, tipoPiso);
	}

	

	public float getAreaSacada() {
		return areaSacada;
	}

	public void setAreaSacada(float areaSacada) {
		this.areaSacada = areaSacada;
	}

	public boolean isElevador() {
		return elevador;
	}

	public void setElevador(boolean elevador) {
		this.elevador = elevador;
	}

	public boolean isChurrasqueira() {
		return churrasqueira;
	}

	public void setChurrasqueira(boolean churrasqueira) {
		this.churrasqueira = churrasqueira;
	}
	
	@Override
	public float gerarPagamentoIPTU() {
		return this.getAreaConstruida() * 20;
		
	}
}
