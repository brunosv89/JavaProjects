
public abstract class Habitacao implements ITributacao{
	
	private int numQuartos;
	private int numBanheiros;
	private boolean garagem;
	private float areaConstruida;

	
	TipoPiso tPiso;
	
	public enum TipoPiso {
		CERAMICO, PORCELANATO, LAMINADO, MARMORE, GRANITO;
	}
	
	
	public Habitacao() {
		this.areaConstruida = 0;
		this.numQuartos = 0;
		this.numBanheiros = 0;
		this.garagem = false;
		this.tPiso = TipoPiso.CERAMICO ;
	}

	public Habitacao(float areaConstruida, int numQuartos, int numBanheiros, boolean garagem, TipoPiso tipoPiso) {
		this.areaConstruida = areaConstruida;
		this.numQuartos = numQuartos;
		this.numBanheiros = numBanheiros;
		this.garagem = garagem;
		this.tPiso = tipoPiso;
	}
	
	
	
	
	public float getAreaConstruida() {
		return areaConstruida;
	}

	public void setAreaConstruida(float areaConstruida) {
		this.areaConstruida = areaConstruida;
	}

	public int getNumQuartos() {
		return numQuartos;
	}

	public void setNumQuartos(int numQuartos) {
		this.numQuartos = numQuartos;
	}

	public int getNumBanheiros() {
		return numBanheiros;
	}

	public void setNumBanheiros(int numBanheiros) {
		this.numBanheiros = numBanheiros;
	}

	public boolean isGaragem() {
		return garagem;
	}

	public void setGaragem(boolean garagem) {
		this.garagem = garagem;
	}

	public TipoPiso gettPiso() {
		return tPiso;
	}

	public void settPiso(TipoPiso tPiso) {
		this.tPiso = tPiso;
	}



	@Override
	public String toString() {
		return "N�mero de quartos �: " + this.numQuartos +
				"\nN�mero de Banheiros �: " + this.numBanheiros +
				"\nTem garagem: " + this.garagem +
				"\nA �rea total constru�da �: " + this.areaConstruida +
				"\nO valor do IPTU � de: " + this.gerarPagamentoIPTU();
	}
	

}
