
public interface ITributacao {	
	
	public float gerarPagamentoIPTU();

}
