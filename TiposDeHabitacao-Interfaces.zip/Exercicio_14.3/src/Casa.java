
public class Casa extends Habitacao {
	
	private float areaPatio;
	public float getAreaPatio() {
		return areaPatio;
	}
	

	public Casa() {
		super();
	}
	public Casa(float areaConstruida, int numQuartos, int numBanheiros, boolean garagem, TipoPiso tipoPiso) {
		super(areaConstruida, numQuartos, numBanheiros, garagem, tipoPiso);
	}
	

	public void setAreaPatio(float areaPatio) {
		this.areaPatio = areaPatio;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	public boolean isPiscina() {
		return piscina;
	}
	public void setPiscina(boolean piscina) {
		this.piscina = piscina;
	}
	private String cor;
	private boolean piscina;

	
	
	@Override
	public float gerarPagamentoIPTU() {
		return this.getAreaConstruida() * 30;
		
	}
	
	


}
