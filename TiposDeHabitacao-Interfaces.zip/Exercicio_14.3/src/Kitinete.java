
public class Kitinete extends Habitacao{


	public Kitinete() {
		super();
	}

	public Kitinete(float areaConstruida, int numQuartos, int numBanheiros, boolean garagem, TipoPiso tipoPiso) {
		super(areaConstruida, numQuartos, numBanheiros, garagem, tipoPiso);
	}

	@Override
	public float gerarPagamentoIPTU() {
		return this.getAreaConstruida() * 10;
	}
	
}
