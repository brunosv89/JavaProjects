//j) Escreva a fun��o main() onde s�o instanciadas as classes derivadas e adicionadas a um
//ArrayList do tipo Habitacao. Itere (percorra) esta lista testando todos os m�todos.

public class Main {

	public static void main(String[] args) {
		Habitacao casa = new Casa();
		Habitacao Apartamento = new Casa();
		Habitacao Kitinete = new Casa();

	}

}
