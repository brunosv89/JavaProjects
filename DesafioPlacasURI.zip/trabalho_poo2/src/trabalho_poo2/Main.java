package trabalho_poo2;


import java.io.IOException;
import java.util.Scanner;

public class Main {
	
	private int nPedidos;
	private Scanner scan = new Scanner(System.in);
	private PCI[] pCliente;
	private PCI pEmpresa;
	
	
    public static void main(String[] args) throws IOException {
		new Main().loop();
	}

	
    /*
      loop principal, que chama os 
      m�todos at� ser interrompido
     */
	private void loop() {
		while(true) {
			if(entradaDados() == false)
				break;
			entradaDados(nPedidos);
			verificaCompatibilidade();
		}
	}
	
	/*
	 m�todo que recebe 3 valores inteiros: as 
	 dimens�es x e y da placa e o n� de pedidos
	 retorno: true se receber input, false se for EOF
	 */
	private boolean entradaDados() {
		System.out.println("Digite as dimens�es da placa produzida pela empresa e a quantidade de pedidos para an�lise: ");

		if(scan.hasNextInt() == false) 
			return false;

		int x = scan.nextInt();		
		int y = scan.nextInt(); 
		if(x<y)
		{
			int aux = x;
			x = y;
			y = aux;
		}
		pEmpresa = new PCI(x,y);
		nPedidos = scan.nextInt();
		return true;
	}
	
	/*
	 recebe de entrada 2 valores das dimens�es x e y 
	 das placas dos clientes um n�mero 'n' de vezes
	 */
	private void entradaDados(int n) {
		pCliente = new PCI[n];
		System.out.println("Digite as dimens�es da placa do cliente: ");
		for (int i=0; i < n; i++)
		{
			System.out.println("Placa " + (i+1) + ": ");
			int x = scan.nextInt();
			int y = scan.nextInt();
			if(x<y)
			{
				int aux = x;
				x = y;
				y = aux;
			}
			pCliente[i] = new PCI(x,y);
		}
	}
	
	/*
	 Compara os atributos da placa modelo da empresa
	 com os atributos da(s) placa(s) do cliente
	 */
	
	private void verificaCompatibilidade(){
		for (int i=0; i < nPedidos; i++)
		{			
			if ((pCliente[i].getX() <= pEmpresa.getX()) && pCliente[i].getY() <= pEmpresa.getY()) {
				System.out.print((i+1) + "� placa: ");
				System.out.println("Sim");
			} else {
				System.out.print((i+1) + "� placa: ");
				System.out.println("Nao");
			}
		}
	}

}


	class PCI {
		private int x;
		private int y;
		
		public PCI(int x, int y) {
			this.x = x;
			this.y = y;
		}

		
		public int getX() {
			return x;
		}

		public int getY() {
			return y;
		}


		
		
	}